// getUser.ts
console.log("hello world");
