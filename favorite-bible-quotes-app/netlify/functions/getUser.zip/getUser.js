// netlify/functions/getUser.ts
console.log("hello world");
